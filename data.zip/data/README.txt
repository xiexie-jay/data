Classroom Physio-Blockchain Dataset (Demo Version)

This repository contains anonymized sample data collected during an 8-week smart-classroom study of 60 middle-school students.
The data illustrate the structure of the full dataset (≈39 M rows at 1 Hz) and may be used for code development, replication
tutorials, or peer-review checks. Real identifying details have been removed.

Important: The files here use a 30-second sampling rate and only the first class period per day. Replace with the full-frequency export if you require the complete dataset.

--------------------------------------------------------------------
File List
--------------------------------------------------------------------
Filename                 | Rows   | Description
-------------------------|--------|---------------------------------------------
physiology_timeseries.csv| 216000 | Per-sample physiological signals (heart rate, skin temperature, EDA, 3-axis acceleration)
session_labels.csv       | 2400   | Per-session subjective & teacher labels (stress, engagement)
weekly_scores.csv        | 480    | Weekly test scores per student
network_metrics.csv      | 200    | Per-session network KPIs (gateway latency, throughput, node power, PDR)
blockchain_metrics.csv   | 1000   | PoA blockchain KPIs (block size, tx count, confirm time)

--------------------------------------------------------------------
Field Definitions
--------------------------------------------------------------------
1. physiology_timeseries.csv
   subject_id              - Pseudonymized student index (1–60)
   timestamp_iso           - ISO-8601 sampling time (local UTC+8)
   heart_rate_bpm          - Photoplethysmography-derived heart rate
   skin_temp_c             - Infrared skin temperature
   eda_usiemens            - Electrodermal activity (galvanic skin response)
   acc_x_g / acc_y_g / acc_z_g - Wrist IMU acceleration

2. session_labels.csv
   stress                  - Student self-reported stress (Likert scale 1–5)
   teacher_engagement      - Teacher-rated engagement (1–5)

3. weekly_scores.csv
   test_score_pct          - Weekly quiz score (0–100%)

4. network_metrics.csv
   gw_latency_ms           - Gateway round-trip latency (ms)
   zigbee_throughput_kbps  - Effective ZigBee throughput (kbps)
   avg_node_power_mw       - Mean node power consumption (mW)
   pkt_delivery_ratio_pct  - Packet delivery ratio (%)

5. blockchain_metrics.csv
   tx_count                - Transactions per block
   confirm_time_ms         - PoA consensus confirmation time (ms)
   block_size_kb           - Serialized block size (kB)
   validator_set_size      - Number of validators (fixed 8)






